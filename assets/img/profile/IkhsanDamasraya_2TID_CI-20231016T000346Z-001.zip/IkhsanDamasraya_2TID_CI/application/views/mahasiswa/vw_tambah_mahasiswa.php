
<div class="container">
    <h2 class="mt-5 text-center">Tambah Data Mahasiswa</h2>
    <form action="<?= site_url('Mahasiswa/simpanData') ?>" method="post">
        <div class="mb-3 col-6 mx-auto">
            <label for="nama" class="form-label">Nama</label>
            <input type="text" class="form-control" id="nama" name="nama" required>
        </div>
        <div class="mb-3 col-6 mx-auto">
            <label for="nim" class="form-label">NIM</label>
            <input type="text" class="form-control" id="nim" name="nim" required>
        </div>
        <div class="mb-3 col-6 mx-auto">
            <label for="jenis_kelamin" class="form-label">Jenis Kelamin</label>
            <select class="form-select" id="jenis_kelamin" name="jenis_kelamin" required>
                <option value="" disabled selected>Pilih Jenis Kelamin</option>
                <option value="L">Laki-Laki</option>
                <option value="P">Perempuan</option>
            </select>
        </div>
        <div class="mb-3 col-6 mx-auto">
            <label for="email" class="form-label">Email</label>
            <input type="email" class="form-control" id="email" name="email" required>
        </div>
        <div class="mb-3 col-6 mx-auto">
            <label for="prodi" class="form-label">Program Studi</label>
            <select class="form-select" id="nama_prodi" name="nama_prodi" required>
                <option value="" disabled selected>Pilih Program Studi</option>
                <!-- Daftar program studi bisa di-generate dari database -->
                <option value="1">Informatika</option>
                <option value="2">Sistem Informasi</option>
                <option value="3">Teknik Elektro</option>
                <!-- Tambahkan lebih banyak program studi sesuai kebutuhan -->
            </select>

        </div>
        <div class="mb-3 col-6 mx-auto">
            <label for="asal_sekolah" class="form-label">Asal Sekolah</label>
            <input type="text" class="form-control" id="asal_sekolah" name="asal_sekolah" required>
        </div>
        <div class="mb-3 col-6 mx-auto">
            <label for="no_hp" class="form-label">No HP</label>
            <input type="text" class="form-control" id="no_hp" name="no_hp" required>
        </div>
        <div class="mb-3 col-6 mx-auto">
            <label for="alamat" class="form-label">Alamat</label>
            <textarea class="form-control" id="alamat" name="alamat" rows="3" required></textarea>
        </div>
        <div class="mb-3 col-6 mx-auto text-center">
            <button type="submit" class="btn btn-primary">Simpan</button>
        </div>
    </form>
</div>



<h1><?php echo $judul; ?> </h1>
<p><?php echo $isi; ?></p>
<p><br> />Page rendered in {elapsed_time} seconds
</p>

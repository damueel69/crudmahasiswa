<br><br><br><br>
<section class="page-section" id="prodiDetail">
	<div class="container">
		<div class="row">
			<div class="col-lg-8 mx-auto">
				<!-- Prodi Detail Card-->
				<div class="card">
					<div class="card-header">
						Detail Program Studi
					</div>
					<div class="card-body">
						<ul class="list-group list-group-flush">
							<li class="list-group-item">Nama Program Studi: <span id="namaProdi"><?= $prodi->nama_prodi ?></span></li>
							<li class="list-group-item">Ruangan: <span id="ruanganProdi"><?= $prodi->ruangan ?></span></li>
							<li class="list-group-item">Jurusan: <span id="jurusanProdi"><?= $prodi->jurusan ?></span></li>
							<li class="list-group-item">Akreditasi: <span id="akreditasiProdi"><?= $prodi->akreditasi ?></span></li>
							<li class="list-group-item">Nama Kaprodi: <span id="namaKaprodi"><?= $prodi->nama_kaprodi ?></span></li>
							<li class="list-group-item">Tahun Berdiri: <span id="tahunBerdiriProdi"><?= $prodi->tahun_berdiri ?></span></li>
							<li class="list-group-item">Output Lulusan: <span id="outputLulusanProdi"><?= $prodi->output_lulusan ?></span></li>
							<a href="<?= site_url('Prodi/') ?>" class="btn btn-secondary">Tutup</a>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>

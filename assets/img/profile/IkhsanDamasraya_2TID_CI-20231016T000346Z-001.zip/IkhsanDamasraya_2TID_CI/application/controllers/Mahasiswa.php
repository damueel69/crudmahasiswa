<?php 
defined('BASEPATH') or exit ('No direct script acces allowed');

class Mahasiswa extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('Mahasiswa_model');
		$this->load->model('Prodi_model');
	}

	public function index()
	{
		// Mengambil data mahasiswa dari model
		$data['mahasiswa'] = $this->Mahasiswa_model->getAllMahasiswa();
		$data['user'] = $this->db->get_where('user',['email'=>$this->session->userdata('email')])->row_array();
		// Mengirim data ke tampilan
		$data['judul'] = "Halaman Mahasiswa";
		$this->load->view("layout/header", $data);
		$this->load->view("mahasiswa/vw_mahasiswa", $data);
		$this->load->view("layout/footer", $data);
	}

	public function updateData($id)
	{
		$data = array(
			'nama' => $this->input->post('nama'),
			'nim' => $this->input->post('nim'),
			'jenis_kelamin' => $this->input->post('jenis_kelamin'),
			'email' => $this->input->post('email'),
			'nama_prodi' => $this->input->post('nama_prodi'),
			'asal_sekolah' => $this->input->post('asal_sekolah'),
			'no_hp' => $this->input->post('no_hp'),
			'alamat' => $this->input->post('alamat')
		);

		$result = $this->Mahasiswa_model->updateMahasiswa($id, $data);

		if ($result) {
			redirect('Mahasiswa');
		} else {
			echo "Gagal menyimpan perubahan data.";
		}
	}

	public function tambah()
	{
		$data['judul'] = "Halaman Tambah Mahasiswa";
		$this->load->view("layout/header");
		$this->load->view("mahasiswa/vw_tambah_mahasiswa", $data);
		$this->load->view("layout/footer");

	}

	public function simpanData()
	{
		$data = array(
			'nama' => $this->input->post('nama'),
			'nim' => $this->input->post('nim'),
			'jenis_kelamin' => $this->input->post('jenis_kelamin'),
			'email' => $this->input->post('email'),
			'nama_prodi' => $this->input->post('nama_prodi'),
			'asal_sekolah' => $this->input->post('asal_sekolah'),
			'no_hp' => $this->input->post('no_hp'),
			'alamat' => $this->input->post('alamat')
		);

		$result = $this->Mahasiswa_model->insertMahasiswa($data);

		if ($result) {
			redirect('Mahasiswa'); 
		} else {
			echo "Gagal menyimpan data.";
		}
	}

	

	public function edit($id)
	{
		// Mengambil data mahasiswa berdasarkan ID
		$data['mahasiswa'] = $this->Mahasiswa_model->getMahasiswaById($id);

		if (empty($data['mahasiswa'])) {
			// Handle jika data mahasiswa tidak ditemukan, bisa berupa redirect atau pesan error
			echo "Data mahasiswa tidak ditemukan.";
		} else {
			// Tampilkan halaman edit dengan data mahasiswa yang telah diambil
			$data['judul'] = "Edit Data Mahasiswa";
			$this->load->view("layout/header");
			$this->load->view("mahasiswa/vw_ubah_mahasiswa", $data);
			$this->load->view("layout/footer");
		}
	}
	 public function detail($id)
    {
        $data['mahasiswa'] = $this->Mahasiswa_model->getMahasiswaById($id);

        if (empty($data['mahasiswa'])) {
            echo "Data mahasiswa tidak ditemukan.";
        } else {
            // Mengambil nama program studi berdasarkan ID mahasiswa
            

            $this->load->view("layout/header");
            $this->load->view("mahasiswa/vw_detail_mahasiswa", $data);
            $this->load->view("layout/footer");
        }
    }

	// controllers/Mahasiswa.php
	public function hapus($id)
	{
		$result = $this->Mahasiswa_model->hapusMahasiswa($id);

		if ($result) {
			redirect('Mahasiswa');
		} else {
			echo "Gagal menghapus mahasiswa.";
		}
	}


}


?>


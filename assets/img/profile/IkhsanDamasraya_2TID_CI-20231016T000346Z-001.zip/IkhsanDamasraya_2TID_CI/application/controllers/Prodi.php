<?php
defined('BASEPATH') or exit('No direct script acces allowed');

// controllers/Prodi.php
class Prodi extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('Prodi_model');
	}

	public function index()
	{
		$data['prodi'] = $this->Prodi_model->getAllProdi();
		$this->load->view("layout/header");
		$this->load->view("prodi/vw_prodi", $data);
		$this->load->view("layout/footer");
	}
	public function detail($id)
	{
		// Mengambil data Prodi berdasarkan ID
		$data['prodi'] = $this->Prodi_model->getProdiById($id);

		if (empty($data['prodi'])) {
			// Handle jika data Prodi tidak ditemukan, bisa berupa redirect atau pesan error
			echo "Data program studi tidak ditemukan.";
		} else {
			// Tampilkan halaman detail dengan data Prodi yang telah diambil
			$this->load->view("layout/header");
			$this->load->view("prodi/vw_detail_prodi", $data);
			$this->load->view("layout/footer");
		}
	}


	public function tambah()
	{
		$this->load->view("layout/header");
		$this->load->view("prodi/vw_tambah_prodi");
		$this->load->view("layout/footer");
	}

	public function simpanData()
	{
		$data = array(
			'nama_prodi' => $this->input->post('nama_prodi'),
			'ruangan' => $this->input->post('ruangan'),
			'jurusan' => $this->input->post('jurusan'),
			'akreditasi' => $this->input->post('akreditasi'),
			'nama_kaprodi' => $this->input->post('nama_kaprodi'),
			'tahun_berdiri' => $this->input->post('tahun_berdiri'),
			'output_lulusan' => $this->input->post('output_lulusan')
		);

		$result = $this->Prodi_model->insertProdi($data);

		if ($result) {
			redirect('Prodi');
		} else {
			echo "Gagal menyimpan data.";
		}
	}

	public function edit($id)
	{
		$data['prodi'] = $this->Prodi_model->getProdiById($id);

		if (empty($data['prodi'])) {
			echo "Data program studi tidak ditemukan.";
		} else {
			$this->load->view("layout/header");
			$this->load->view("prodi/vw_edit_prodi", $data);
			$this->load->view("layout/footer");
		}
	}

	public function updateData()
	{
		$id = $this->input->post('id');
		$data = array(
			'nama_prodi' => $this->input->post('nama_prodi'),
			'ruangan' => $this->input->post('ruangan'),
			'jurusan' => $this->input->post('jurusan'),
			'akreditasi' => $this->input->post('akreditasi'),
			'nama_kaprodi' => $this->input->post('nama_kaprodi'),
			'tahun_berdiri' => $this->input->post('tahun_berdiri'),
			'output_lulusan' => $this->input->post('output_lulusan')
		);

		$result = $this->Prodi_model->updateProdi($id, $data);

		if ($result) {
			redirect('Prodi');
		} else {
			echo "Gagal mengupdate data.";
		}
	}
	// controllers/Kaprodi.php
	public function hapus($id)
	{
		// Panggil model untuk menghapus prodi berdasarkan ID
		$result = $this->Prodi_model->hapusProdi($id);

		if ($result) {
			// Redirect kembali ke halaman daftar prodi jika penghapusan berhasil
			redirect('Prodi');
		} else {
			// Tampilkan pesan error atau tindakan lain jika penghapusan gagal
			echo "Gagal menghapus prodi.";
		}
	}


}

?>

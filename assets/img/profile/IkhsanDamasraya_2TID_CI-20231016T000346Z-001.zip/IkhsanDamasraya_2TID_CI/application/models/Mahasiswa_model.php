<?php
// application/models/Mahasiswa_model.php
class Mahasiswa_model extends CI_Model
{
	public function insertMahasiswa($data)
	{
		$this->db->insert('mahasiswa', $data);

		return $this->db->affected_rows() > 0;
	}

	public function getAllMahasiswa()
	{
		return $this->db->get('mahasiswa')->result();
	}

	public function getMahasiswaById($id)
	{
		$this->db->select('m.*,p.nama_prodi as prodi');
		$this->db->from('mahasiswa m');
		$this->db->join('prodi p', 'm.nama_prodi = p.id');
		$this->db->where('m.id', $id);
		$query = $this->db->get();
		return $query->row_array();
	}

	public function updateMahasiswa($id, $data)
	{
		$this->db->where('id', $id);
		$this->db->update('mahasiswa', $data);

		return $this->db->affected_rows() > 0;
	}

	// models/Mahasiswa_model.php
	public function hapusMahasiswa($id)
	{
		return $this->db->delete('mahasiswa', array('id' => $id));
	}



}

?>

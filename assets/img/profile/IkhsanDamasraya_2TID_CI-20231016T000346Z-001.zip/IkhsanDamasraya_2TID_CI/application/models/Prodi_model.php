<?php

// application/models/Prodi_model.php
class Prodi_model extends CI_Model
{
	public function insertProdi($data)
	{
		$this->db->insert('prodi', $data);

		return $this->db->affected_rows() > 0;
	}

	public function getAllProdi()
	{
		return $this->db->get('prodi')->result();
	}

	public function getProdiById($id)
	{
		return $this->db->get_where('prodi', array('id' => $id))->row();
	}

	public function updateProdi($id, $data)
	{
		$this->db->where('id', $id);
		$this->db->update('prodi', $data);

		return $this->db->affected_rows() > 0;
	}

	// models/Kaprodi_model.php
	public function hapusProdi($id)
	{
		return $this->db->delete('prodi', array('id' => $id));
	}



}


?>
